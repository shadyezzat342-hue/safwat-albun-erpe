Safwat Al-Bun ERP V26.4 — Android Build Status

What was verified in V26.4:
- Android Gradle Plugin: 8.6.1
- Gradle distribution target: 8.7
- compileSdk / targetSdk: 35
- minSdk: 23
- Java compatibility: 17
- Application package: com.safwatalbun.erp
- AndroidManifest and MainActivity reviewed
- JavaScript bridge and asset entry file present
- Version metadata unified to 26.4 / versionCode 28

Important:
The official binary gradle-wrapper.jar is not present in the current project package and Android SDK is not available in this execution environment. Therefore an actual Gradle APK compilation has NOT been claimed as successful.
The launcher scripts were corrected so they fail clearly instead of accidentally invoking an unrelated system Gradle.

Next required external build test:
1. Restore official gradle-wrapper.jar matching Gradle 8.7.
2. Run ./gradlew :app:assembleDebug in an environment with Android SDK 35 and build tools.
3. Install generated APK and test startup, backup, restore and export.
