Safwat Al-Bun ERP V26.3 — Android Finalization

Validated changes:
- Android-aware backup saving.
- Native Android restore bridge.
- Browser fallback retained.
- File chooser accepts requested types.
- Backup metadata updated to V26.3.
- Reduced unnecessary network configuration.
- Build helper scripts and wrapper properties added.

Important: This package is build-ready but is not falsely labeled as an already compiled APK.
