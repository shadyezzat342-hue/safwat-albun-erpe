V26.1 Android Integration - Internal test report
- Native Android save bridge implemented for Blob/CSV/JSON/text exports.
- Android ACTION_CREATE_DOCUMENT used to let the user choose the save location.
- Native JSON backup picker implemented.
- Standard WebView HTML file inputs supported through WebChromeClient.
- JavaScript bridge added without altering ERP business logic.
- Version bumped to 26.1 / versionCode 27.
Remaining external validation required: actual Android Gradle build and device/emulator runtime test.
