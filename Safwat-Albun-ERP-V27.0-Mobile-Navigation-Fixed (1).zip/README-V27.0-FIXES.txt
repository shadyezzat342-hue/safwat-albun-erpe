Safwat Al-Bun ERP V27.0
- Fixed Android mobile menu hidden below 600px.
- Added mobile navigation drawer.
- Unified go/showPage navigation.
- Expenses and cash legacy routes mapped to working finance pages.
- Removed orphan duplicated HTML/JS fragment.
