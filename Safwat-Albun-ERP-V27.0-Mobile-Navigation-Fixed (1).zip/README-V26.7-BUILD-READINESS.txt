Safwat Al-Bun ERP V26.7 Build Readiness

Actual changes:
- GitHub Actions pipeline now explicitly installs Android SDK Platform 35 and Build Tools 35.0.0.
- JDK 17 and Gradle 8.7 are pinned in CI.
- APK output is verified before artifact upload.
- VersionCode/versionName unified to 31/26.7.

Important: This package has not been compiled in the current local environment because Android SDK is not installed here. The workflow is prepared for actual cloud compilation.
