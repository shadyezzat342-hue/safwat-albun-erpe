package com.safwatalbun.erp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ConsoleMessage;
import android.widget.Toast;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private static final int REQUEST_PICK_FILE = 1001;
    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;

    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setDatabaseEnabled(true);
        s.setSupportZoom(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onConsoleMessage(ConsoleMessage consoleMessage){
                return super.onConsoleMessage(consoleMessage);
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
                if(fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                String[] types=params.getAcceptTypes();
                intent.setType(types!=null && types.length>0 && types[0]!=null && !types[0].isEmpty()?types[0]:"*/*");
                try { startActivityForResult(intent, REQUEST_PICK_FILE); }
                catch(ActivityNotFoundException e){
                    fileChooserCallback = null;
                    Toast.makeText(MainActivity.this,"لا يوجد مدير ملفات متاح",Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidApp");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidBridge {
        @JavascriptInterface public String platform(){ return "Android"; }
        @JavascriptInterface public void saveBase64File(String fileName, String mimeType, String base64Data){
            runOnUiThread(() -> {
                try {
                    byte[] data = Base64.decode(base64Data, Base64.DEFAULT);
                    String safe = fileName == null || fileName.trim().isEmpty() ? "Safwat-Albun-Export.txt" : fileName.replaceAll("[\\\\/:*?\"<>|]", "_");
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(mimeType == null || mimeType.isEmpty() ? "application/octet-stream" : mimeType);
                    intent.putExtra(Intent.EXTRA_TITLE, safe);
                    pendingSaveBytes = data;
                    pendingSaveMime = mimeType;
                    startActivityForResult(intent, REQUEST_SAVE_FILE);
                } catch(Exception e){ Toast.makeText(MainActivity.this,"تعذر تجهيز الملف",Toast.LENGTH_SHORT).show(); }
            });
        }
        @JavascriptInterface public void openBackupFile(){ runOnUiThread(() -> openBackupPicker()); }
    }

    private static final int REQUEST_SAVE_FILE = 1002;
    private byte[] pendingSaveBytes;
    private String pendingSaveMime;

    private void openBackupPicker(){
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, REQUEST_PICK_FILE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode == REQUEST_PICK_FILE){
            Uri uri = resultCode == RESULT_OK && data != null ? data.getData() : null;
            if(fileChooserCallback != null){ fileChooserCallback.onReceiveValue(uri == null ? null : new Uri[]{uri}); fileChooserCallback=null; return; }
            if(uri != null){ try{ getContentResolver().takePersistableUriPermission(uri, data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION)); }catch(Exception ignored){} readBackupIntoPage(uri); }
        } else if(requestCode == REQUEST_SAVE_FILE && resultCode == RESULT_OK && data != null && pendingSaveBytes != null){
            try {
                try(java.io.OutputStream os=getContentResolver().openOutputStream(data.getData())){ os.write(pendingSaveBytes); os.flush(); }
                Toast.makeText(this,"تم حفظ الملف بنجاح",Toast.LENGTH_SHORT).show();
            } catch(Exception e){ Toast.makeText(this,"تعذر حفظ الملف",Toast.LENGTH_SHORT).show(); }
            pendingSaveBytes=null;
        }
    }

    private void readBackupIntoPage(Uri uri){
        try(InputStream in=getContentResolver().openInputStream(uri); ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buf=new byte[8192]; int n; while((n=in.read(buf))!=-1) out.write(buf,0,n);
            String base64=Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);
            webView.evaluateJavascript("window.SafwatAndroidRestore && window.SafwatAndroidRestore('"+base64+"')", null);
        } catch(Exception e){ Toast.makeText(this,"تعذر قراءة ملف النسخة الاحتياطية",Toast.LENGTH_SHORT).show(); }
    }

    @Override protected void onDestroy(){
        if(webView != null){
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.clearHistory();
            webView.removeAllViews();
            webView.destroy();
            webView=null;
        }
        super.onDestroy();
    }

    @Override public void onBackPressed(){ if(webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
