Safwat Al-Bun ERP V26.6

تم حل مشكلة عدم وجود Android SDK وGradle محلياً بإضافة Build Pipeline سحابي رسمي عبر GitHub Actions.

البناء يتم في بيئة Ubuntu تحتوي على JDK 17 وGradle 8.7، ثم يتم رفع APK الناتج كـ Artifact.

الأمر المستخدم:
  gradle :app:assembleDebug --no-daemon --stacktrace

التوافق:
- Android Gradle Plugin: 8.6.1
- Gradle: 8.7
- Java: 17
- compileSdk: 35
- targetSdk: 35
- minSdk: 23

ملاحظة: Gradle Wrapper JAR لم يتم اختلاقه أو تضمينه من مصدر غير موثوق. بدلاً من ذلك، تم إضافة بناء سحابي يثبت Gradle الرسمي المحدد ثم يبني المشروع فعلياً.
